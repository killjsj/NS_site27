﻿using DisplayKit.Elements;
using Exiled.API.Features;
using MEC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NS_site27_api.Core.UI.DisplayKit
{
    public struct PlayerDisplayer
    {
        public DisplayCanvas canvas;
        public DisplayLayer displayLayer;
        public override int GetHashCode()
        {
            return displayLayer.GetHashCode();
        }
    }
    public class DisplayKitRunner
    {
        public static DisplayKitRunner Instance;
        private HashSet<DisplayLayer> Layers = new();
        private long UpdateTimeMs = 0;
        private Dictionary<Player,HashSet<PlayerDisplayer>> Players = new();

        public void RegisterLayer(DisplayLayer layer)
        {
            if (layer == null) return;
            Layers.Add(layer);
            long ms = Math.Max(
                1,
                (long)layer.updateTime.TotalMilliseconds
            );
            if (UpdateTimeMs == 0)
                UpdateTimeMs = ms;
            else
                UpdateTimeMs = GCD(UpdateTimeMs, ms);
        }
        public IEnumerator<DisplayLayer> GetLayers()
        {
            return Layers.GetEnumerator();
        }
        public DisplayLayer? GetLayer(string id)
        {
            return Layers.Where(x=>x.Id == id).FirstOrDefault();
        }
        public DisplayLayer? UnregisterLayer(string id)
        {
            var l = GetLayer(id);
            if (l != null)
            {
                Layers.Remove(l);
            }
            return l;
        }
        public DisplayLayer? UnregisterLayer(DisplayLayer l)
        {
            if (l != null)
            {
                Layers.Remove(l);
            }
            return l;
        }

        public void AddLayer(Player player, DisplayLayer layer)
        {
            if (!Layers.Contains(layer))
            {
                RegisterLayer(layer);
            }
            if (!Players.TryGetValue(player, out var l))
            {
                l = new();
                Players[player] = l;
            }
            var c = DisplayCanvas.Create();
            layer.InitNodes(player, c);
            var er = new PlayerDisplayer() { canvas = c, displayLayer = layer };
            l.Add(er);
            c.Show(player.ReferenceHub);
        }
        public void AddLayer(Player player, string id)
        {
            var layer = GetLayer(id);
            if (layer == null)
            {
                return;
            }
            if (!Players.TryGetValue(player, out var l))
            {
                l = new();
                Players[player] = l;
            }
            var c = DisplayCanvas.Create();
            layer.InitNodes(player, c);
            var er = new PlayerDisplayer() { canvas = c, displayLayer = layer };
            l.Add(er);
            c.Show(player.ReferenceHub);
        }

        public IEnumerator<float> Updater()
        {
            while (true)
            {
                try
                {
                    foreach (var item in Players)
                    {
                        try
                        {
                            foreach (var item1 in item.Value)
                            {
                                try
                                {
                                    item1.displayLayer.Update(item.Key, item1.canvas);
                                }
                                catch (Exception ex)
                                {
                                    Log.Error($"Failed to update ui at player:{item.Key} in id: {item1.displayLayer?.Id} due:{ex}");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Log.Error($"Failed to update ui at player:{item.Key} due:{ex}");
                        }
                    }
                }
                catch (Exception ex) {
                    Log.Error($"Failed to update ui due:{ex}");
                }
                yield return Timing.WaitForSeconds(UpdateTimeMs/1000f);
            }
        }
        public void SetVisible(bool vis, Player player, DisplayLayer layer)
        {
            if (!Players.TryGetValue(player, out var l))
            {
                l = new();
                Players[player] = l;
                return;
            }
            var r = l.FirstOrDefault(x => x.displayLayer == layer);
            if (r.displayLayer == null)
            {
                return;
            }
            r.displayLayer.SetVisible(vis, player, r.canvas);
        }
        public void SetVisible(bool vis, Player player, string id)
        {
            var layer = GetLayer(id);
            if (layer == null)
            {
                return;
            }
            if (!Players.TryGetValue(player, out var l))
            {
                l = new();
                Players[player] = l;
                return;
            }
            var r = l.FirstOrDefault(x => x.displayLayer == layer);
            if (r.displayLayer == null)
            {
                return;
            }
            r.displayLayer.SetVisible(vis, player, r.canvas);
        }
        public void RemoveLayer(Player player, DisplayLayer layer)
        {
            if (!Layers.Contains(layer))
            {
                RegisterLayer(layer);
            }
            if (!Players.TryGetValue(player, out var l))
            {
                l = new();
                Players[player] = l;
                return;
            }
            var re = l.FirstOrDefault(x => x.displayLayer == layer);
            if (re.displayLayer == null)
            {
                return;
            }
            re.displayLayer.DestroyNodes(player, re.canvas);
            if (re.canvas != null)
            {
                re.canvas.Destroy();
            }
            l.Remove(re);
        }
        public void RemoveLayer(Player player, string id)
        {
            var layer = GetLayer(id);
            if (layer == null)
            {
                return;
            }
            if (!Players.TryGetValue(player, out var l))
            {
                l = new();
                Players[player] = l;
                return;
            }
            var re = l.FirstOrDefault(x => x.displayLayer == layer);
            if (re.displayLayer == null)
            {
                return;
            }
            re.displayLayer.DestroyNodes(player, re.canvas);
            if (re.canvas != null)
            {
                re.canvas.Destroy();
            }
            l.Remove(re);
        }

        CoroutineHandle CH;
        void OnWaiting()
        {
            CH = Timing.RunCoroutine(Updater());
        }
        public void Disable()
        {
            Instance = null;
            Exiled.Events.Handlers.Server.WaitingForPlayers -= OnWaiting;

        }
        public void Enable()
        {
            Instance = this;
            Exiled.Events.Handlers.Server.WaitingForPlayers += OnWaiting;
        }
        private static long GCD(long x, long y)
        {
            x = Math.Abs(x);
            y = Math.Abs(y);

            while (y != 0)
            {
                long t = x % y;
                x = y;
                y = t;
            }

            return x;
        }
    }
    public static class DisplayKitExt
    {
        public static void AddLayer(this Player player, DisplayLayer layer)
        {
            DisplayKitRunner.Instance.AddLayer(player, layer);
        }
        public static void AddLayer(this Player player, string id)
        {
            DisplayKitRunner.Instance.AddLayer(player, id);
        }
        public static void SetVisible(this Player player, bool vis,DisplayLayer layer)
        {
            DisplayKitRunner.Instance.SetVisible(vis,player, layer);
        }
        public static void SetVisible(this Player player, bool vis,string id)
        {
            DisplayKitRunner.Instance.SetVisible(vis,player, id);
        }
        public static void RemoveLayer(this Player player, DisplayLayer layer)
        {
            DisplayKitRunner.Instance.RemoveLayer(player, layer);
        }
        public static void RemoveLayer(this Player player, string id)
        {
            DisplayKitRunner.Instance.RemoveLayer(player, id);
        }
    }
}
